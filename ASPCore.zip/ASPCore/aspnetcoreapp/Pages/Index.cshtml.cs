using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

public class IndexModel : PageModel
{
    public void OnPost()
    {
        string operation = Request.Form["operation"];
        double num1 = string.IsNullOrEmpty(Request.Form["num1"]) ? 0 : Convert.ToDouble(Request.Form["num1"]);
        double num2 = string.IsNullOrEmpty(Request.Form["num2"]) ? 0 : Convert.ToDouble(Request.Form["num2"]);
        double result = 0;

        switch (operation)
        {
            case "ADD":
                result = num1 + num2;
                break;
            case "SUB":
                result = num1 - num2;
                break;
            case "MUL":
                result = num1 * num2;
                break;
            case "DIV":
                result = num2 != 0 ? num1 / num2 : double.NaN; // Avoid division by zero
                break;
            case "CUBE":
                result = Math.Pow(num1, 3);
                break;
            case "SIN":
                result = Math.Sin(num1 * Math.PI / 180); // Convert degrees to radians
                break;
            case "COS":
                result = Math.Cos(num1 * Math.PI / 180); // Convert degrees to radians
                break;
            default:
                ViewData["result"] = "Invalid operation!";
                return;
        }

        ViewData["result"] = $"The result is: {result}";
    }
}
